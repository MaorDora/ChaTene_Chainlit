class Config:
    exception_logger = None
    use_legacy_attributes = True
